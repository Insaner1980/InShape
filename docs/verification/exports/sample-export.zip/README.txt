InShape CSV export
UTF-8, comma-separated, every field quoted, doubled internal quotes, CRLF row endings. Quoted fields can contain newlines.
Dates use ISO 8601. Times marked UTC include their offset. Decimal loads use a dot. Empty fields mean not recorded or excluded, not zero. Stable IDs link tables.
Only selected completed records are exported. Exercise rows contain performed work, including partial exercises. Sets contain completed sets only. COMPLETION_ONLY does not imply a set.
To prevent spreadsheet formulas, text whose first non-space character is =, +, - or @, or which starts with a tab or line break, is prefixed with one apostrophe. Remove that prefix to recover such text. The full backup preserves exact original text.
Notes included: true. Check-ins included: true.
